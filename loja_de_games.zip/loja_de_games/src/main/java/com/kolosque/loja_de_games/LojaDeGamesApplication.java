package com.kolosque.loja_de_games;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LojaDeGamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LojaDeGamesApplication.class, args);
	}

}
