package com.kolosque.loja_de_games;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LojaDeGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
