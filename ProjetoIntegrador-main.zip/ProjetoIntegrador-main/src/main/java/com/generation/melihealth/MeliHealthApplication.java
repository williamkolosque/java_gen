package com.generation.melihealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeliHealthApplication {

    public static void main(String[] args) {
        SpringApplication.run(MeliHealthApplication.class, args);
    }

}
