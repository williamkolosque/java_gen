package com.generation.melihealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeliHealthApplicationTests {

    @Test
    void contextLoads() {
    }

}
